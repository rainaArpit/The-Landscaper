﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Landscaper
{
    class Program
    {
        enum eAppointmentSlots
        {
            AM_9 = 1,
            AM_10 = 2,
            AM_11 = 3,
            PM_12 = 4,
            PM_1 = 5,
            PM_2 = 6,
            PM_3 = 7,
            PM_4 = 8
        }

        enum eTypeOfProperties
        {
            townhouse,
            standalone,
            largeRural
        }

        Customer[] customerObj = new Customer[10];
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Go();
            Console.ReadKey();
        }

        public void Go()
        {
            var slotTimings = Enum.GetNames(typeof(eAppointmentSlots));
            var slotValues = Enum.GetValues(typeof(eAppointmentSlots));

            Appointments[] appointments = new Appointments[slotTimings.Length];

            ArrayList arAppointmentList = new ArrayList();

            bool isAppointmentRequired = false;

            for (int i = 0; i < slotTimings.Length; i++)
            {
                arAppointmentList.Add(slotTimings[i]);

                appointments[i] = new Appointments();
                appointments[i].AppointmentNumber = i + 1;
                appointments[i].Time = slotTimings[i];
            }

            do
            {

                string reply = string.Empty;
                do
                {
                    Console.WriteLine("Do you need an Appointment? (Y or N)");
                    reply = Console.ReadLine();

                } while ((reply != "Y") && (reply != "N"));

                if( reply == "N" )
                {
                    isAppointmentRequired = false;
                    continue;
                }


                for( int i = 0; i < arAppointmentList.Count; i++)
                {
                    Console.WriteLine("{0}.  {1}",i+1 , arAppointmentList[i]);
                }

                string slotChoice = string.Empty;
                int choice = 0;
                do
                {
                    Console.Write("Please choose from the available slots. (Press 0 to exit) ");
                    slotChoice = Console.ReadLine();
                } while (!int.TryParse(slotChoice, out choice) || (choice < 0 || choice > arAppointmentList.Count));




                string lotSize = string.Empty;
                string workingArea = string.Empty;
                string noOfWorkers = string.Empty;
                string noOfDays = string.Empty;
                string creditCard = string.Empty;

                if (choice == 0)
                {
                    isAppointmentRequired = false;
                    continue;
                }

                else if ((choice > 0) && (choice <= arAppointmentList.Count))
                {
                    do {
                        Console.Write("What is the size of your plot in meter square. We dont take projects more than 50,000 meter square.  ");
                        lotSize = Console.ReadLine();
                    } while ((int.Parse(lotSize) < 0) || (int.Parse(lotSize) > 50000 ));

                    do {
                        Console.Write("What is the working area in that plot.  ");
                        workingArea = Console.ReadLine();
                        if(int.Parse(lotSize) < int.Parse(workingArea))
                        {
                            Console.WriteLine("Working Area cannot be More than your Lot Size");
                            Console.WriteLine();
                        }
                    } while (int.Parse(workingArea) < 0 || (int.Parse(lotSize) < int.Parse(workingArea)));

                    Console.WriteLine("What type of property is it?  ");
                   
                    var typeOfProperties = Enum.GetValues(typeof(eTypeOfProperties));
                    int num = 1;
                    foreach (var type in typeOfProperties)
                    {
                        Console.WriteLine("{0}. {1}", num++, type);
                    }
                    string propType = String.Empty;
                    int opt = 0;
                    do
                    {
                        Console.Write("Choose your property type.  ");
                        propType = Console.ReadLine();
                    } while ((!int.TryParse(propType, out opt)) || (opt < 0) || (opt > typeOfProperties.Length));

                    do {
                        Console.Write("How many days of work is it? (Not more than 2 Years)  ");
                        noOfDays = Console.ReadLine();
                    } while((int.Parse(noOfDays) < 0) || (int.Parse(noOfDays) > 730));

                    do {
                        Console.Write("How many workers are required? We Have only 100 Workers in total.  ");
                        noOfWorkers = Console.ReadLine();
                    } while ((int.Parse(noOfWorkers) < 0) || (int.Parse(noOfWorkers) > 100));

                    do {
                        Console.WriteLine("Enter your 16 digit credit card number.  ");
                        creditCard = Console.ReadLine();
                    } while (creditCard.Length != 16);


                    string sentence = creditCard;
                    char[] charArr = sentence.ToCharArray();
 
                    for ( int i =  0; i < creditCard.Length; i++)
                    {
                        if (i > 3)
                        {
                            charArr[i] = 'x';
                        }

                    }
                    creditCard = new string(charArr);

                    Customer myCustomer = null;

                    switch(opt - 1)
                    {
                        case (int)eTypeOfProperties.townhouse:
                            Console.WriteLine();
                            Console.WriteLine(" *NOTE* - We will need to get neighbor's consent.");
                            myCustomer = new Townhouse(int.Parse(lotSize), int.Parse(workingArea), int.Parse(noOfDays), int.Parse(noOfWorkers), creditCard);
                            Console.WriteLine(); 
                            break;

                        case (int)eTypeOfProperties.standalone:
                            Console.WriteLine();
                            Console.WriteLine(" *NOTE* - We will need to clear the entrance to the lot");
                            myCustomer = new Standalone(int.Parse(lotSize), int.Parse(workingArea), int.Parse(noOfDays), int.Parse(noOfWorkers), creditCard);
                            Console.WriteLine(); 
                            break;
                        case (int)eTypeOfProperties.largeRural:
                            Console.WriteLine();
                            Console.WriteLine(" *NOTE* - We will need to clear the working area");
                            myCustomer = new LargeRural(int.Parse(lotSize), int.Parse(workingArea), int.Parse(noOfDays), int.Parse(noOfWorkers), creditCard);
                            Console.WriteLine(); 
                            break;
                        default :
                            Console.WriteLine("Error");
                            break;
                    }
                    

                    appointments[choice - 1].Customer = myCustomer;

                    isAppointmentRequired = true;

                    arAppointmentList.RemoveAt(choice - 1);

                }

            } while ((isAppointmentRequired) && (arAppointmentList.Count > 0));


            for (int i = 0; i < appointments.Length; i++)
            {
                if (appointments[i].Customer != null)
                {
                    Console.WriteLine("Time: {0}, Customer: {1}", appointments[i].Time, appointments[i].Customer);
                    Console.WriteLine();
                }
            }
            Console.ReadKey();
        }

    }
}
