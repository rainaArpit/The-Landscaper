﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Landscaper
{
    class Appointments
    {
        private string time;
        private Customer customer;
        private int appointmentNumber;

        public string Time { get => time; set => time = value; }
        public int AppointmentNumber { get => appointmentNumber; set => appointmentNumber = value; }

        internal Customer Customer { get => customer; set => customer = value; }
    }
}
