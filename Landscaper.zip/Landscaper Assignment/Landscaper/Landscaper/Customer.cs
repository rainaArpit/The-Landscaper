﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Landscaper
{
    class Customer
    {


        private int sizeOfLot;
        private int sizeOfWorkingArea;
        private int daysOfWork;
        private int numberOfWorkers;

        private string propertyType;
        private string creditCardNumber;

        public int SizeOfLot { get => sizeOfLot; set => sizeOfLot = value; }
        public int SizeOfWorkingArea { get => sizeOfWorkingArea; set => sizeOfWorkingArea = value; }
        public int DaysOfWork { get => daysOfWork; set => daysOfWork = value; }
        public int NumberOfWorkers { get => numberOfWorkers; set => numberOfWorkers = value; }

        public string CreditCardNumber { get => creditCardNumber; set => creditCardNumber = value; }
        public string PropertyType { get => propertyType; set => propertyType = value; }



        public override string ToString()
        {
            return string.Format("Size of Lot is: {} and the working area is: {}. The work will take {} days and {} workers. Your Credit Card details are {}.");
        }
    }

}