﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Landscaper
{
    class Townhouse : Customer
    {
        public Townhouse() { }
        public Townhouse(int size, int workingArea, int days, int workers, string credit)
        {
            SizeOfLot = size;
            SizeOfWorkingArea = workingArea;
            DaysOfWork = days;
            NumberOfWorkers = workers;
            CreditCardNumber = credit;
        }

        public override string ToString()
        {
            return string.Format("Size of Lot is: {0} and the working area is: {1}. The work will take {2} days and {3} workers. Your Credit Card details are {4}. We will have to get your neighbor's consent.",
                                SizeOfLot, SizeOfWorkingArea, DaysOfWork,NumberOfWorkers, CreditCardNumber);
        }
    }
}
